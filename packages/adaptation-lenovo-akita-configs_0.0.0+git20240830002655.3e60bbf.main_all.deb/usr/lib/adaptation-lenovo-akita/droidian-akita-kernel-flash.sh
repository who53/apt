#!/bin/bash

if grep -q androidboot.atm /proc/cmdline; then
  	exit 0
else
	/usr/bin/dd if=/dev/droidian/droidian-persistent of=/dev/disk/by-partlabel/boot bs=1M
fi
