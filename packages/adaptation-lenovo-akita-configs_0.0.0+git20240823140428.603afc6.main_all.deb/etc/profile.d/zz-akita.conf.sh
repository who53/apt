export GDK_DEBUG=gl-prefer-gl
