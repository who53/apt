#!/bin/bash

if grep -q androidboot.atm /proc/cmdline; then
  	exit 0
	echo "shame on you" > /home/droidian/file-of-shame
else
	/usr/bin/dd if=/dev/droidian/droidian-persistent of=/dev/disk/by-partlabel/boot bs=1M
	echo "I did it" > /home/droidian/hehe
fi
